StoreHandler.AddItem( 'store', {
            id = 1,
            name = '.357 Magnum',
            ent = 'weapon_357',
            model = 'models/weapons/w_357.mdl',
                 colors = { foreground = Color( 113, 57, 156 ), outline = Color( 174, 68, 255 ) } ,
 
            description = ".357 Magnum",
            price = 1337,
            page = 'Weapons',
            properties = {
                permanent_item = true, type = 'Weapon',
                main_fov = 85, can_feature = false, force_set_feature = false
            }
        } )

-- vk.com/urbanichka

            StoreHandler.CreateStore({
                id = 'store',
                overhead = 'store1',
                model = 'models/barney.mdl',
                description = "Item shop",
                position = { 
                    { pos = Vector( 706, -309, -128), angle = Angle(3, 0, 0) }
                },
                store_name = '',
                store_categories = { { tab = 'Weapons', feature_time = 30 }   },
                spawn_chance = 100,
           })

-- vk.com/urbanichka
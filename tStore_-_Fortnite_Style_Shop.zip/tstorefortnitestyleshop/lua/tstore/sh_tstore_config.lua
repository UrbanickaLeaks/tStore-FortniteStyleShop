
    StoreHandler.Currency = 'DarkRP' -- DarkRP, PointShop1, PointShop2, basewars

    StoreHandler.MessagePrefix = '[Market]' -- The prefix of a message sent in chat from tStore.
    StoreHandler.PrefixColor = Color( 245, 59, 87 ) -- The Color of the prefix
    StoreHandler.MessageColor = Color( 255, 255, 255 ) -- The Color of the message

    StoreHandler.CanOpenWithCommand = true
    StoreHandler.OpenStoreCommand = '/market' -- Opens the first (made) NPC
    StoreHandler.ClearItemsCommand = '/tclear' -- The command for superadmin's to use to clear items or inventories.
    StoreHandler.AddItemCommand = '/tadd' -- The command used to add items to a player. (Donation command etc)

    StoreHandler.Themes.Choice = 'Classic' -- Fortnite or Classic.
    StoreHandler.AdminMod = 'serverguard' -- ulx or serverguard

    StoreHandler.GiveWeaponsOnSpawn = false -- Give users the items they own when they spawn?

    -- vk.com/urbanichka


    if not CLIENT then return end


    StoreHandler.Themes[ 'Classic' ] = {
        menu_header_bar = Color( 42, 42, 42 ),
        item_top_header = Color( 42, 42, 42 ),
        item_bottom_header = Color( 30, 39, 46 ),
        general_text_color = Color( 255, 255, 255 ),
        exit_button_color = Color( 234, 32, 39, 125 ),
        exit_button_hover_color = Color( 234, 32, 39, 180 ),
        money_text_color = Color( 5, 196, 107 )
    }

-- vk.com/urbanichka
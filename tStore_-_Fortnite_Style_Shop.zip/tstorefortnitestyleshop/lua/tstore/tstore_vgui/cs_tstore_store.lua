

    if not CLIENT then return end

    include( 'cs_tstore_other.lua' )

    function StoreHandler.ManageFonts( min, max, font ) -- No idea why I didn't do this sooner.
        for x = min, max do surface.CreateFont( 'gNite.Font.' .. x, {
            font = font, size = x, weight = 0
        } ) end
    end

    StoreHandler.ManageFonts( 12, 80, StoreHandler.UsingClassic() and 'BFHUD' or 'Luckiest Guy' )

    local current_page = ''
    local updated_page = ''

    local classic_theme = StoreHandler.Themes[ 'Classic' ]
    local classic = StoreHandler.UsingClassic()
    local lang = StoreHandler.Languages[ 'Default' ]

    function StoreHandler.Button( parent, x, y, w, h, font, txt, col, circle, exit )
        local btn = vgui.Create( 'DButton', parent )
        local textColor = Color( 255, 255, 255 )
        btn:SetSize( w, h )
        btn:SetFont( font )
        btn.tstore_text = txt 
        btn:SetText( '' )
        btn:SetPos( x, y )
        btn.Paint = function( me, w, h )
            local color = Color( 255, 255, 255 )
            if circle then 
                StoreHandler.DrawRoundedBox( 8, 0, 0, w, h, col )
            else
                if me.tstore_text == current_page or me:IsHovered() then 
                    StoreHandler.DrawRect( 0, 0, w, h, exit and classic_theme.exit_button_hover_color or Color( 255, 244, 0 ) )
                    color = Color( 0, 0, 0 )
                else
                    StoreHandler.DrawRect( 0, 0, w, h, exit and classic_theme.exit_button_color or Color( 65, 61, 63 ) )
                end
            end
            StoreHandler.DrawText( me.tstore_text, font, w / 2, h / 2 - ( classic and 16 or 14 ), color )
        end
        return btn
    end

    local header = Material( 'tstore_header.png' )
    local item_description = Material( 'tstore_featured.png' )
    local gradient = Material( 'tstore_gradient.png' )
    local circle = Material( 'tstore_arrow.png' )
    local rank_icon = Material( 'tstore_rank.png', 'noclamp smooth' )
    local star_icon = Material( 'tstore_star.png', 'noclamp smooth' )
    local store_id, id, lower_res = '', '', ScrW() <= 1600

    local items, data, save, selection = {}, {}, {}, {}

    local function DrawTexture( icon, x, y, w, h, col )
        surface.SetDrawColor( col )
        surface.SetMaterial( icon )
        surface.DrawTexturedRect( x, y, w, h )
    end

    local function DrawLoadIcon(xpos, ypos, w, h)

        local offset = (w / 3) * math.sin(CurTime())
        surface.SetDrawColor( 255, 255, 255 )
        surface.SetMaterial( circle )
        surface.DrawTexturedRectRotated(xpos, ypos, w + offset, h + offset, CurTime() * 360)

    end 

    local function HandleModelLogic( model, v, fov, cam_pos )

        local vec_space = { [ 'entity' ] = Vector( 120, 90, 30 ), [ 'prop' ] = Vector( 120, 90, 30 ) }

        model.LayoutEntity = function() return end
        local mn, mx = model.Entity:GetRenderBounds()
        local size = 0
        size = math.max( size, math.abs(mn.x) + math.abs(mx.x) )
        size = math.max( size, math.abs(mn.y) + math.abs(mx.y) )
        size = math.max( size, math.abs(mn.z) + math.abs(mx.z) )

        local type = string.lower( v.properties.type )

        model:SetCamPos( vec_space[ type ] or Vector( size, size, size ) )
        model:SetLookAt( type ~= 'model' and ( mn + mx ) * ( v.properties.item_direction_x or 0.55 ) - Vector( 0, 0, v.properties.item_direction_y or 0 ) or Vector( 10, 0, 40 ) )
        model:SetFOV( v.properties.main_fov )

    end

    function StoreHandler.OwnsItem( id )
        for k, v in pairs( save ) do if v == id then return true end end
    end

    function StoreHandler.GetItemsInLocker()
        local content = {}
        for k, v in pairs( StoreHandler.NPCs ) do
            for x, o in pairs( v.store_items ) do
                local lower = string.lower( o.properties.type )
                if lower ~= 'weapon' and lower ~= 'model' then continue end
                for j, k in pairs( save ) do
                    if o.id == k then table.insert( content, o ) end
                end
            end
        end
        return content
    end

    function StoreHandler.BuildFeaturedSection( base, scr_w, scr_h, featured_layout, featured_section, tbl, force_reset ) 
        if not IsValid( base ) then return end
        featured_layout:Clear()
        for k, v in pairs( tbl ) do

            local type = string.lower( v.properties.type )
            local handlesImage = type == 'rank' or type == 'perk'
            local owns_item, price = StoreHandler.OwnsItem( v.id ), '$0'
            
            local pnl = vgui.Create( 'DPanel', featured_layout )
            pnl:SetSize( featured_layout:GetWide() / 2 - 2, featured_layout:GetTall() )


            pnl.Paint = function( me, w, h )

                local x = w / 2

                if not feature_manager[ current_page ].is_switching_state then
                    if not owns_item then price = StoreHandler.Price( v.price ) else price = 'Item Purchased' end
               end

                local switching = feature_manager[ current_page ].is_switching_state

                local shader_pos = scr_h * 0.494
                local weapon_text_y = scr_h * ( not lower_res and 0.502 or 0.485 )
                local display_text_y = scr_h * ( not lower_res and 0.535 or 0.525 )

                StoreHandler.DrawRect( 0, 0, w, h, v.colors.foreground )
                StoreHandler.DrawOutline( 0, 0, w, h, me:IsHovered() and 3 or 4, me:IsHovered() and Color( 255, 244, 0 ) or v.colors.outline )
                
                StoreHandler.DrawRect( 3, shader_pos, w - scr_w * 0.003, scr_h * 0.08, Color( 0, 0, 0, 100 ) )

                DrawTexture( gradient, 0, -10, w, h * 0.02, Color( 255, 255, 255 ) )
                StoreHandler.DrawText( not switching and v.name or 'Loading', 'StoreHandler.Font.FeaturedSection', x, weapon_text_y, Color( 255, 255, 255 ) )
                StoreHandler.DrawText(  not switching and v.properties.type or 'Unknown' or 'Loading', 'StoreHandler.Font.FeaturedSection', x, display_text_y, Color( 255, 255, 255 ) )
                StoreHandler.DrawRect( 3, h * 0.936, w - scr_w * 0.003, scr_h * 0.035, classic and classic_theme.item_bottom_header or Color( 28, 34, 56 ) )

                StoreHandler.DrawText( price, 'StoreHandler.Font.FeaturedSectionMin', x, h - scr_h * ( classic and 0.039 or 0.037 ), Color( 255, 255, 255 ) )
                if v.properties.permanent_item and not switching then
                    --StoreHandler.DrawRect( 4, 4, w - 8, 40, Color( 0, 0, 0, 130 ) )
                    local white_flash = 100 + math.abs( math.sin( CurTime() * 2 ) * 255 )
                    StoreHandler.DrawRect( 4, 4, w - 8, scr_h * 0.037, Color( 0, 0, 0, 175 ) )
                    StoreHandler.DrawText( lang.perm_item_string, 'StoreHandler.Font.FeaturedSection', x, classic and 3 or 5, Color( white_flash, white_flash, white_flash ) )
                end
                if handlesImage then DrawTexture( switching and DrawLoadIcon( w / 2, h / 2, 64, 64 ) or type == 'rank' and star_icon or '', w / 2 - 100, scr_h * 0.16, 200, 200, Color( 255, 255, 255 ) ) end
            end

            pnl.OnMousePressed = function()
                if switching then return end
                net.Start( 'StoreHandler.Manage.Action' )
                    net.WriteInt( v.id, 8 )
                    net.WriteBool( owns_item )
                net.SendToServer()
                base:Close()
            end

            if handlesImage then featured_layout:AddItem( pnl ) continue end

            local model = vgui.Create( 'DModelPanel', pnl )
            model:SetSize( scr_w * 0.20, scr_h * 0.37 )
            model:SetPos( 10, pnl:GetTall() / 2 - scr_h * 0.37 / 2 )
            model:SetMouseInputEnabled( false )
            model:SetAnimated( true )
            model:SetModel( not force_reset and v.model or '' )

            if not force_reset then
                HandleModelLogic( model, v )
            else
                timer.Simple( 2, function() 
                    if IsValid( base ) then 
                        model:SetModel( v.model ) 
                        HandleModelLogic( model, v )
                    end 
                end )
            end

            model.Paint = function( me, w, h )
                if feature_manager[ current_page ].is_switching_state then DrawLoadIcon( w / 2 + 32, h / 2, 64, 64 ) end
                baseclass.Get( 'DModelPanel' ).Paint( me, w, h )
            end
            featured_layout:AddItem( pnl )
        end
    end

    function StoreHandler.BuildRegularSection( base, scr_w, scr_h, regular_section, regular_layout, tbl, current_page )
        if not IsValid( regular_layout ) then return end
        regular_layout:Clear()
        for k, v in pairs( tbl ) do
            if v.properties.can_feature or v.properties.force_set_feature then continue end
            if v.page ~= current_page then continue end
            local type = string.lower( v.properties.type )

            local handlesImage = type == 'rank' or type == 'perk'
            local ship_type = type == 'shipment' and v.properties.type .. ' x ' .. ( v.properties.shipment_amount or 10 )
            local owns_item, price = StoreHandler.OwnsItem( v.id ), '$0'


            local pnl = vgui.Create( 'DPanel', regular_layout )
            pnl:SetSize( regular_layout:GetWide() / 3 - 7, scr_h * ( not lower_res and 0.29 or 0.3 ) )
            pnl.Paint = function( me, w, h )
                local x = w / 2

                if not owns_item then price = StoreHandler.Price( v.price ) else price = 'Item Purchased' end

                local white_flash = 100 + math.abs( math.sin( CurTime() * 2 ) * 255 )
                StoreHandler.DrawRect( 0, 0, w, h, v.colors.foreground )
                StoreHandler.DrawOutline( 0, 0, w, h, me:IsHovered() and 3 or 2, me:IsHovered() and Color( 255, 244, 0 ) or v.colors.outline )
                StoreHandler.DrawRect( 5, ( h - scr_h * 0.081 ) - 6, w - 10, scr_h * 0.082, Color( 0, 0, 0, 100 ) )
                DrawTexture( gradient, 1, -4, w - 2, h + 17, Color( 255, 255, 255 ) )
                StoreHandler.DrawText( v.name, 'StoreHandler.Font.RegularSectionMax', x, scr_h * ( not lower_res and 0.21 or 0.22 ), Color( 255, 255, 255 ) )
                StoreHandler.DrawText( ship_type or v.properties.type, 'StoreHandler.Font.RegularSection', x, scr_h * ( not lower_res and 0.236 or 0.245 ), Color( 255, 255, 255 ) )
                StoreHandler.DrawRect( 3, h - scr_h * 0.025, w - 6, scr_h * 0.023, classic and classic_theme.item_bottom_header or Color( 28, 34, 56 ) )
                StoreHandler.DrawText( price, 'StoreHandler.Font.RegularSection', x, h - scr_h * ( classic and 0.027 or 0.025 ), StoreHandler.OwnsItem( v.id ) and Color( white_flash, white_flash, white_flash ) or Color( 255, 255, 255 ) )
                if v.properties.permanent_item then 
                    StoreHandler.DrawRect( 4, 4, w - 8, scr_h * 0.028, Color( 0, 0, 0, 175 ) )
                    StoreHandler.DrawText( lang.perm_item_string, 'StoreHandler.Font.RegularSection', x, classic and 5 or 7, Color( white_flash, white_flash, white_flash ) )
                end
                if handlesImage then DrawTexture( type == 'rank' and rank_icon or '', x - 61, 60, 128, 128, Color( 255, 255, 255 ) ) end
            end

            pnl:SetToolTip( v.description )  

            pnl.OnMousePressed = function()
                net.Start( 'StoreHandler.Manage.Action' )
                    net.WriteInt( v.id, 8 )
                    net.WriteBool( false )
                net.SendToServer()
                base:Close()
            end

            if handlesImage then regular_layout:AddItem( pnl ) continue end

            local model = vgui.Create( 'DModelPanel', pnl )
            model:SetSize( scr_w * 0.1095, scr_h * 0.204 )
            model:SetPos( 25, ( pnl:GetWide() / 2 - scr_w * 0.1095 / 2 ) - 15 )
            model:SetMouseInputEnabled( false )
            model:SetModel( v.model )

            HandleModelLogic( model, v )

            regular_layout:AddItem( pnl )
        end
    end

    StoreHandler.Menu_Active = false

    local current_id = ''

    function StoreHandler.CatchFeatureChange()
        if not StoreHandler.Menu_Active then return end
        local content = {}
        local updated = net.ReadString()
        if updated ~= current_id then return end
        feature_manager, updated_page, save = net.ReadTable(), net.ReadString(), net.ReadTable()[ LocalPlayer():SteamID() ] or {}
        StoreHandler.ConstructSections( true )
    end
    net.Receive( 'StoreHandler.Process.FeatureUpdate', StoreHandler.CatchFeatureChange )

    function StoreHandler.BuildLockerInterface( base, scr_w, scr_h, live_preview_section, your_items_section, live_preview_header, tbl, scroll_item )
        scroll_item:Clear()
        live_preview_section:Clear()
        selection = nil

        local weapon_preview = vgui.Create( 'DModelPanel', live_preview_section )
        weapon_preview:SetPos( scr_w * 0.117, scr_h * 0.01 )
        weapon_preview:SetMouseInputEnabled( false )
        weapon_preview:SetModel( '' )
        weapon_preview:SetSize( scr_w * 0.2, scr_h * 0.42 )
        weapon_preview.Paint = function( me, w, h )
            baseclass.Get( 'DModelPanel' ).Paint( me, w, h )
            if selection then 
                StoreHandler.DrawText( selection.name, 'StoreHandler.Font.FeaturedSection', w / 2, scr_h * 0.357, Color( 255, 255, 255 ) ) 
                StoreHandler.DrawText( selection.properties.type, 'StoreHandler.Font.FeaturedSection', w / 2, scr_h * 0.387, Color( 255, 255, 255 ) ) 
            end
        end
        --HandleModelLogic( weapon_preview, v )
                                                                        
        local item_description = vgui.Create( 'DLabel', live_preview_section )
        item_description:SetContentAlignment( 7 )
        item_description:SetPos( 12, scr_h * ( not lower_res and 0.439 or 0.435 ) )
        item_description:SetSize( live_preview_section:GetWide(), 300 )
        item_description:SetWrap( true )
        item_description:SetFont( 'StoreHandler.Font.FeaturedSectionMin' )
        item_description:SetText( '' )
        item_description:SetTextColor( Color( 255, 255, 255 ) )

        for k, v in pairs( StoreHandler.GetItemsInLocker() ) do
            local foreground_color = v.colors.foreground
            local outline_color = v.colors.outline

            local pnl = vgui.Create( 'DPanel', regular_layout )
            pnl:SetSize( scroll_item:GetWide() / 3 - 7, scr_h * ( not lower_res and 0.305 or 0.31 ) )
            pnl.Paint = function( me, w, h )

                local shader_pos = scr_h * 0.216
                local name_display_y = scr_h * 0.222
                local type_display_y = scr_h * 0.248
                
                StoreHandler.DrawRect( 0, 0, w, h, foreground_color )
                StoreHandler.DrawOutline( 0, 0, w, h, me:IsHovered() and 3 or 2, me:IsHovered() and Color( 255, 244, 0 ) or outline_color )
                StoreHandler.DrawRect( scr_w * 0.0021, shader_pos, w - scr_w * 0.0042, scr_h * 0.06, Color( 0, 0, 0, 100 ) )
                StoreHandler.DrawRect( scr_w * 0.0016, scr_h * 0.275, w - scr_w * 0.00315, scr_h * 0.028, classic and classic_theme.item_bottom_header or Color( 28, 34, 56 ) )

                StoreHandler.DrawText( v.name, 'StoreHandler.Font.RegularSectionMax', w / 2, name_display_y, Color( 255, 255, 255 ) )
                StoreHandler.DrawText( v.properties.type or 'Unknown', 'StoreHandler.Font.RegularSection', w / 2, type_display_y, Color( 255, 255, 255 ) )
                StoreHandler.DrawText( lang.perm_item_string, 'StoreHandler.Font.RegularSection', w / 2 - 3, scr_h * ( classic and 0.276 or 0.277), Color( 255, 255, 255 ) )
                
                --StoreHandler.DrawRect( w / 2, 0, 1, h, Color( 200, 0, 0 ) )
            end

            pnl.OnMousePressed = function()
                net.Start( 'StoreHandler.Manage.Action' )
                    net.WriteInt( v.id, 8 )
                    net.WriteBool( true )
                net.SendToServer()
                base:Close()
            end

            pnl.OnCursorEntered = function()  
                weapon_preview:SetModel( v.model )
                HandleModelLogic( weapon_preview, v ) 
                item_description:SetText( v.description or lang.string_no_description )
                selection = v
                live_preview_header:SetVisible( true )
                live_preview_section:SetVisible( true )
            end

            local model = vgui.Create( 'DModelPanel', pnl )
            model:SetSize( scr_w * 0.1095, scr_h * 0.204 )
            model:SetPos( scr_w * ( not lower_res and 0.017 or 0.015 ), pnl:GetWide() / 2 - scr_w * 0.1095 / 2 )
            model:SetMouseInputEnabled( false )
            model:SetModel( v.model )
            HandleModelLogic( model, v )

            scroll_item:AddItem( pnl )
        end
    end

    function StoreHandler.CreateParentPanel( base, pOneX, pOneY, pOneW, pOneH, strRight, strLeft, increase, format )
        increase = increase or 0
        if format then strRight = strRight .. '%s' end
        local section_one = vgui.Create( 'DPanel', base )
        section_one:SetPos( pOneX, pOneY )
        section_one:SetSize( pOneW, pOneH )

        local y = classic and 3 or 5

        section_one.Paint = function( me, w, h ) 
            if classic then
                StoreHandler.DrawRect( 0, 0, w, 43, classic_theme.item_top_header )
            else
                DrawTexture( item_description, -20, 0, w + 40, 43, Color( 255, 255, 255 ) )
            end
            StoreHandler.DrawText( format and string.format( strRight, current_page ) or strRight, 'gNite.Font.33', 8, y, classic and classic_theme.general_text_color or Color( 179, 188, 207 ), TEXT_ALIGN_LEFT )
            if type( strLeft ) == 'boolean' then
                if not feature_manager[ current_page ].page_has_features then return end
                local time = math.Round( feature_manager[ current_page ].feature_length - math.abs( feature_manager[ current_page ].start_time - CurTime() ) )
                StoreHandler.DrawText( not feature_manager[ current_page ].is_switching_state and StoreHandler.SecondsToClock( time ) or '00:00', 'gNite.Font.30', w - 10, y, feature_manager[ current_page ].is_switching_state and Color( 235, 77, 75 ) or time < 16 and time > 8 and Color( 240, 147, 43) or time < 9 and Color( 235, 77, 75 ) or Color( 255, 255, 255 ), TEXT_ALIGN_RIGHT )
            else
                StoreHandler.DrawText( strLeft, 'gNite.Font.30', w - 20, y, Color( 255, 255, 255 ), TEXT_ALIGN_RIGHT )
            end
        end

        local layout_section = vgui.Create( 'DPanelList', section_one )
        layout_section:SetPos( 0, 46 )
        layout_section:SetSize( section_one:GetWide() + increase, section_one:GetTall() - ScrH() * ( not lower_res and 0.042 or 0.14 ) )
        layout_section:SetSpacing( 4 )
        layout_section:EnableVerticalScrollbar( true )
        layout_section:EnableHorizontal( true )
        --layout_section.Paint = function( me, w, h ) StoreHandler.DrawRect( 0, 0, w, h, Color( 200, 0, 0 ) ) end

        StoreHandler.PaintBar( layout_section, nil, nil, Color( 255, 255, 255 ) )

        return section_one, layout_section
    end

    function StoreHandler.HandleStoreInterface()
        StoreHandler.Menu_Active = true
        local self, locker_open = LocalPlayer(), false
        feature_manager, id, save = net.ReadTable(), net.ReadString(), net.ReadTable()

        data = StoreHandler.NPCs[ id ]
        current_page, updated_page, current_id = data.store_categories[ 1 ].tab, current_page, id

        local scr_w, scr_h = ScrW(), ScrH()

        local base = vgui.Create( 'store_menu' )
        base:SetSize( scr_w, scr_h )
        base:Center()

        base:ShowClose( false )
        base:MakePopup()

        local exit = StoreHandler.Button( base, base:GetWide() - 135, 14, 125, 40, 'gNite.Font.29', classic and lang.close_button_string or string.upper( lang.close_button_string ), Color( 135, 141, 164 ), false, true )
        exit.DoClick = function() base:Close() end

        self.Start = CurTime()
        base.Paint = function( me, w, h )
            StoreHandler.GenerateScreenBlur( me, me.Start )
            me.alpha = Lerp( 0.1, 5, 1 )
            StoreHandler.BlurMenu( me, 4, 4, 255 * me.alpha )
            StoreHandler.DrawRect( 0, 0, w, h, Color( 0, 0, 0, 220 ) )
            if classic then 
                StoreHandler.DrawRect( 0, 0, w, 65, classic_theme.menu_header_bar )
                StoreHandler.DrawRect( 0, h - 42, w, 42, classic_theme.menu_header_bar )
            else
                DrawTexture( header, 0, 0, w, 800, Color( 255, 255, 255 ) )
                StoreHandler.DrawRect( 0, h - 42, w, 42, Color( 28, 34, 56 ) )
            end
            StoreHandler.DrawText( data.store_name or 'Unknown', 'gNite.Font.43', 10, 9, Color( 255, 255, 255 ), TEXT_ALIGN_LEFT )
            StoreHandler.DrawText( StoreHandler.Price( string.lower( StoreHandler.Currency ) == 'darkrp' and DarkRP and self:getDarkRPVar( 'money' ) or string.lower( StoreHandler.Currency ) == 'pointshop1' and self:PS_GetPoints() or string.lower( StoreHandler.Currency ) == 'pointshop2' and self..PS2_Wallet.points or string.lower( StoreHandler.Currency ) == 'basewars' and self:GetMoney() or 'Unknown' ), 'gNite.Font.35', w - 150, 15, classic and classic_theme.money_text_color or Color( 255, 255, 255 ), TEXT_ALIGN_RIGHT )
            StoreHandler.DrawRoundedBox( 8, 25, h - 93, w - 50, 35, Color( 60, 60, 60, 150 ) )
            StoreHandler.DrawText( data.description, 'gNite.Font.30', w / 2, h - 93, Color( 255, 255, 255 ) )
        end


        local global_main_w = scr_w * ( not lower_res and 0.468 or 0.485 )

        local this = lang.featured_items_string_left
        local featured_x, featured_y = scr_w * 0.008, scr_h * ( not lower_res and 0.13 or 0.17 )
        local featured_h = scr_h * ( not lower_res and 0.657 or 0.75 )
        local fTextRight = classic and this or string.upper( this )
        local featured_section, featured_layout = StoreHandler.CreateParentPanel( base, featured_x, featured_y, global_main_w, featured_h, fTextRight, true, 0, true )

        this = lang.regular_items_string_left
        local regular_x, regular_y = scr_w * ( not lower_res and 0.52 or 0.51 ), scr_h * ( not lower_res and 0.13 or 0.17 )
        local regular_h = scr_h * ( not lower_res and 0.657 or 0.75 )
        local rTextRight = classic and this or string.upper( this )
        local regular_section, regular_layout = StoreHandler.CreateParentPanel( base, regular_x, regular_y, global_main_w, regular_h, rTextRight, 'No Time Limit', 5, true )

        this = lang.your_items_string_left
        local items_x, items_y = scr_w * 0.008, scr_h * ( not lower_res and 0.13 or 0.16 )
        local items_h = base:GetTall() - scr_h * 0.23
        local iTextRight = classic and this or string.upper( this )
        local your_items_section, item_layout = StoreHandler.CreateParentPanel( base, items_x, items_y, global_main_w + 20, items_h, iTextRight, '', 0, false )
        your_items_section:SetVisible( false )

        local live_preview_header = vgui.Create( 'DPanel', base )
        live_preview_header:SetPos( scr_w * ( not lower_res and 0.52 or 0.51 ), scr_h * ( not lower_res and 0.13 or 0.16 ) )
        live_preview_header:SetSize( scr_w * ( not lower_res and 0.47 or 0.485 ),  scr_h * ( not lower_res and  0.64 or 0.75 ) )
        live_preview_header:SetVisible( false )
        live_preview_header.Paint = function( me, w, h ) 
            if classic then
                StoreHandler.DrawRect( 0, 0, w, 43, Color( 32, 32, 32 ) )
            else
                DrawTexture( item_description, -30, 0, w + 50, 43, Color( 255, 255, 255 ) )
            end
            StoreHandler.DrawText( classic and lang.item_preview_string_left or string.upper( lang.item_preview_string_left ), 'gNite.Font.33', 8, classic and 4 or 7, classic and Color( 255, 255, 255 ) or Color( 179, 188, 207 ), TEXT_ALIGN_LEFT )
        end


        local live_preview_section = vgui.Create( 'DPanel', live_preview_header )
        live_preview_section:SetSize( live_preview_header:GetWide(), scr_h * ( not lower_res and 0.540 or 0.6 ) )
        live_preview_section:SetVisible( false )
        live_preview_section.Paint = function( me, w, h ) 
            StoreHandler.DrawRect( 0, scr_h * 0.043, w, h, selection.colors.foreground or Color( 99, 110, 114 ) )
            StoreHandler.DrawRect( 2, scr_h * 0.365, w - 4, scr_h * 0.074, Color( 0, 0, 0, 100 ) )
            StoreHandler.DrawRect( 2, scr_h * 0.4385, w - 4, scr_h * ( not lower_res and 0.1 or 0.16 ), classic and classic_theme.item_bottom_header or Color( 28, 34, 56 ) )
        end

        function StoreHandler.ConstructSections( force_reset, reject )
            if not IsValid( base ) then return end
            local tbl, block_featured = feature_manager, false
            if force_reset and updated_page ~= current_page then return end -- We aren't on that page, no point updating.
            StoreHandler.BuildRegularSection( base, scr_w, scr_h, regular_section, regular_layout, data.store_items, current_page )
            if force_reset then 
                tbl[ current_page ].is_switching_state = true
                timer.Simple( 2, function() 
                    if IsValid( base ) and tbl[ current_page ].is_switching_state then tbl[ current_page ].is_switching_state = false end 
                end )
            end
            StoreHandler.BuildFeaturedSection( base, scr_w, scr_h, featured_layout, featured_section, feature_manager[ current_page ].featured_items or {}, force_reset )
        end

        StoreHandler.ConstructSections( false, true )

        local button_panel = vgui.Create( 'DPanelList', base )
        button_panel:SetPos( ScrW() * ( not lower_res and 0.35 or 0.3 ), 40 )
        button_panel:SetSize( ScrW() * 0.55, 45 )
        button_panel:SetSpacing( 10 )
        button_panel:EnableHorizontal( true )
        button_panel:SetVisible( #data.store_categories > 1 )

        for k, v in pairs( data.store_categories ) do
            local font = 'gNite.Font.29'
            surface.SetFont( font )
            local w, h = surface.GetTextSize( v.tab )
            local b_pan_x, b_pan_y = button_panel:GetPos()
            if #data.store_categories > 3 then button_panel:SetPos( b_pan_x - ScrW() * 0.012, 40 ) end
            local start_x = base:GetWide() / 2 - 125 / 2
            local btn = StoreHandler.Button( base, -325 + ( start_x + k * 133 ), 40, 30 + surface.GetTextSize( v.tab ), 14 + h, font, v.tab, Color( 135, 141, 164 ) )
            btn.DoClick = function()
                current_page = btn.tstore_text
                StoreHandler.ConstructSections( false, true )
            end
            button_panel:AddItem( btn )
        end

        local on_locker_show = {}
        on_locker_show.hide = { featured_section, regular_section }
        on_locker_show.show = { your_items_section }
        on_locker_show.open = false

        local locker = StoreHandler.Button( base, scr_w * 0.009, scr_h * ( not lower_res and 0.073 or 0.09 ), scr_w * ( not lower_res and 0.1 or 0.15 ), 50, 'gNite.Font.30', classic and lang.view_locker_string or string.upper( lang.view_locker_string ), Color( 135, 141, 164 ) )
        locker.DoClick = function( me )
            if not on_locker_show.open then 
                on_locker_show.open = true 
                me.tstore_text = classic and lang.view_store_string or string.upper( lang.view_store_string )
                for k, v in pairs( on_locker_show.hide ) do v:SetVisible( false ) end
                for k, v in pairs( on_locker_show.show ) do v:SetVisible( true ) end
                StoreHandler.BuildLockerInterface( base, scr_w, scr_h, live_preview_section, your_items_section, live_preview_header, StoreHandler.GetItemsInLocker(), item_layout )
            else 
                on_locker_show.open = false 
                me.tstore_text = classic and lang.view_locker_string or string.upper( lang.view_locker_string )
                for k, v in pairs( on_locker_show.hide ) do v:SetVisible( true ) end
                for k, v in pairs( on_locker_show.show ) do v:SetVisible( false ) end
                live_preview_header:SetVisible( false )
            end
        end
    end
    net.Receive( 'StoreHandler.Send.StoreItems', StoreHandler.HandleStoreInterface )

-- vk.com/urbanichka
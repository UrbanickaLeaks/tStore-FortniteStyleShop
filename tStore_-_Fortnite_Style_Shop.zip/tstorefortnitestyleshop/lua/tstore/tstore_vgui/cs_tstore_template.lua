

    if not CLIENT then return end
    
    local PANEL = {}

    function PANEL:SetHeader( header ) self.StoreHeader = header end

    function PANEL:ShowClose( bShowClose )
        if not bShowClose then return end
        self.ExitButton = vgui.Create( 'DLabel', self )
        self.ExitButton:SetPos( self:GetWide() - 30, 0 )
        self.ExitButton:SetMouseInputEnabled( true )
        self.ExitButton:SetSize( 32, 34 )
        self.ExitButton:SetText( '' )
        self.ExitButton:SetCursor( 'hand' )
        self.ExitButton.Paint = function( me, w, h )
            Delicate_UI.DrawText( 'x', 'gNite.Font.30', w / 2, -1, me:IsHovered() and Color( 200, 0, 0 ) or Color( 255, 255, 255 ) )
        end
        self.ExitButton.DoClick = function() self:Close() StoreHandler.Menu_Active = false end
    end

    function PANEL:Init()
        self.StoreHeader = ''
        self.bShowClose = true

        self:SetSize( ScrW() * 0.5, ScrH() * 0.7 )
        self:SetDraggable( false )
        self:SetTitle( '' )
        self:ShowCloseButton( false )
        self:Center()
        self:MakePopup()
    end

    vgui.Register( 'store_menu', PANEL, 'DFrame' )

-- vk.com/urbanichka
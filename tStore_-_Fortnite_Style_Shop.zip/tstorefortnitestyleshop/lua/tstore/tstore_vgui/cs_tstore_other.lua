

    if not CLIENT then return end

    local font = StoreHandler.UsingClassic() and 'BFHUD' or 'Luckiest Guy'

    surface.CreateFont( 'StoreHandler.Font.RegularSection', { font = font, size = ScreenScale( 8 ), weight = 700 } )
    surface.CreateFont( 'StoreHandler.Font.RegularSectionMax', { font = font, size = ScreenScale( 9 ), weight = 700 } )
    surface.CreateFont( 'StoreHandler.Font.FeaturedSection', { font = font, size = ScreenScale( 12 ), weight = 700 } )
    surface.CreateFont( 'StoreHandler.Font.FeaturedSectionMin', { font = font, size = ScreenScale( 10 ), weight = 700 } )

    net.Receive( 'StoreHandler.Display.Message', function()
        chat.AddText( StoreHandler.PrefixColor, StoreHandler.MessagePrefix .. ': ', StoreHandler.MessageColor, net.ReadString() or '' )
    end )

-- vk.com/urbanichka
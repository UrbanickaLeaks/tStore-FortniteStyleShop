

    if not SERVER then return end

    StoreHandler.FeatureManager = StoreHandler.FeatureManager or {}
    local lang = StoreHandler.Languages[ 'Default' ]

    function StoreHandler.CanAfford( self, price )
        local currency = string.lower( StoreHandler.Currency )
        if currency == 'darkrp' then
            if not self:canAfford( price ) then return false end
        elseif currency == 'pointshop1' then
            if not self:PS_HasPoints( price ) then return false end
        elseif currency == 'pointshop2' then
            if self.PS2_Wallet.points < price then return false end
        elseif currency == 'basewars' then
            if self:GetMoney() < price then return false end
        else
            return false
        end
        return true
    end

    function StoreHandler.TakeCurrency( self, price )
        local currency = string.lower( StoreHandler.Currency )
        if currency == 'darkrp' then
            self:addMoney( - price )
        elseif currency == 'pointshop1' then
            self:PS_TakePoints( price )
        elseif currency == 'pointshop2' then
            self:PS2_AddStandardPoints( - price )
        elseif currency == 'basewars' then
            self:TakeMoney( price )
        end
    end

    function StoreHandler.FindStoreItem( id )
        for k, v in pairs( StoreHandler.NPCs ) do
            for x, o in pairs( v.store_items ) do
                if o.id == id then return true, o end
            end
        end
    end

    function StoreHandler.OwnsItem( self, id )
        for k, v in pairs( StoreHandler.Saves[ self:SteamID() ] or {} ) do if v == id then return true end end
    end

    util.AddNetworkString( 'StoreHandler.Display.Message' )
    function StoreHandler.SendMessage( self, str )
        net.Start( 'StoreHandler.Display.Message' )
            net.WriteString( str )
        net.Send( self )
    end

    function StoreHandler.GetFeatureSize( id, page )
        local pageSize = 0
        for k, v in pairs( StoreHandler.NPCs[ id ].store_items or {} ) do
            if v.page ~= page then continue end
            if v.properties.can_feature or v.properties.force_set_feature then
                pageSize = pageSize + 1
            end
        end
        return pageSize
    end

    function StoreHandler.CreateEntity( self, item )
        local ent = ents.Create( item.ent or 'store_ent_base' )
        ent:SetModel( item.model )
        ent:SetPos( ( self:GetPos() + ( self:GetForward() * 40 ) ) + Vector( 0, 0, 40 ) )
        ent:CPPISetOwner( self )
        if ent.Setowning_ent then ent:Setowning_ent( self ) end
        ent:Spawn()
        local phys = ent:GetPhysicsObject()
        if phys:IsValid() then phys:Wake() end
    end

    function StoreHandler.CreateShipment( self, item )
        if not DarkRP then print( string.format( 'Error creating %s, gamemode is not %s', item.name, 'DarkRP' ) ) return end
        local ent = ents.Create( 'spawned_shipment' )
        local key, amt = nil, 10
        for k, v in pairs( CustomShipments ) do
            if not item.ent then continue end -- Leak by Scora
            if v.entity == item.ent then key = k amt = v.amount end
        end
        if not key then print( 'Item ' .. item.name .. ' not found as a shipment.' ) return end
        ent:SetPos( self:GetPos() + Vector( 80, 0, 40 ) )
        ent:SetPlayer( self )   
        ent:SetContents( key, amt )
        ent:Spawn()
        ent.SID = self.SID
    end

    function StoreHandler.HandleRank( self, item )
        if not item.rank then print( item.name .. ' has no rank privilege set to it. Rank can not be bought.' ) return end
        if item.rank == self:GetUserGroup() then StoreHandler.SendMessage( self, lang.string_same_rank ) return end
        if string.lower( StoreHandler.AdminMod ) == 'ulx' then
            RunConsoleCommand( 'ulx', 'adduser', self:Nick(), item.rank )
        elseif string.lower( StoreHandler.AdminMod ) == 'serverguard' then
            serverguard.player:SetRank( self, item.rank, true )
        end
    end

    function StoreHandler.GrabPossibleItems( id, page )
        local items = {}
        for k, v in pairs( StoreHandler.NPCs[ id ].store_items ) do
            if v.page ~= page then continue end
            if not v.properties.can_feature then continue end
            table.insert( items, v )
        end
        return items
    end

    hook.Add( 'PlayerSay', 'StoreHandler.Catch.ChatCommand', function( self, txt )
            if string.sub( txt, 1, #StoreHandler.OpenStoreCommand ) == StoreHandler.OpenStoreCommand and StoreHandler.CanOpenWithCommand then
                local id = table.GetFirstKey( StoreHandler.NPCs )
                if not StoreHandler.NPCs[ id ] then print( 'Error on Store ID.' ) return '' end
                if StoreHandler.NPCs[ id ].restricted_to and not StoreHandler.NPCs[ id ].restricted_to[ self:GetUserGroup() ] then
                    StoreHandler.SendMessage( self, 'You do not have permission to use this store.' )
                    return ''
                end
                net.Start( 'StoreHandler.Send.StoreItems' )
                    net.WriteTable( StoreHandler.FeatureManager[ id ] )
                    net.WriteString( id )
                    net.WriteTable( StoreHandler.Saves[ self:SteamID() ] or {} )
                net.Send( self )
                self.tstore_last_id = id
                return ''
            elseif string.sub( txt, 1, #StoreHandler.ClearItemsCommand ) == StoreHandler.ClearItemsCommand and self:IsSuperAdmin() then
                local splitStr = string.Split( txt, ' ' )
                if not splitStr[ 2 ] then StoreHandler.SendMessage( self, 'Error, missing Steam ID.' ) return '' end
                local steam_id = splitStr[ 2 ]
                if not string.find( steam_id, 'STEAM_' ) then StoreHandler.SendMessage( self, 'Error, invalid Steam ID passed.' ) return '' end
                local complete_wipe = not splitStr[ 3 ] and true or false
                if complete_wipe then StoreHandler.Saves[ steam_id ] = {} else table.RemoveByValue( StoreHandler.Saves[ steam_id ], tonumber( splitStr[ 3 ] ) ) end
                StoreHandler.SendMessage( self, complete_wipe and string.format( 'All of %s\'s items have been deleted.', steam_id ) or string.format( 'You have removed ID %s from %s.', splitStr[ 3 ], steam_id ) )
                return ''
            end
    end )

    concommand.Add( 'tstore_offer_perm_item', function( self, cmd, args )
        if IsValid( self ) and not self:IsSuperAdmin() then return end
        local steamid, id = args[ 1 ], tonumber( args[ 2 ] )
        if not steamid or not id then print( 'Missing Steam ID or item ID.' ) return end
        local target = player.GetBySteamID( steamid )
        if not IsValid( target ) then target = player.GetBySteamID64( steamid ) end
        if IsValid( target ) then
            local found, item = StoreHandler.FindStoreItem( id )
            if not found or found and not item.properties.permanent_item then print( 'This item does not exist, or is not permanent.' ) return end
            local lowered = string.lower( item.properties.type )
            if lowered ~= 'model' and lowered ~= 'weapon' then print( 'You can not add this item to their locker, only Weapons and Models may be added.' ) return end
            if StoreHandler.Saves[ target:SteamID() ] then
                if table.HasValue( StoreHandler.Saves[ target:SteamID() ], id ) then print( 'Error, this user already has this item' ) return end
                StoreHandler.WriteStoreData( target, id ) 
                print( string.format( 'Item %s (ID %i) has been added to %s\'s Inventory.', item.name, id, steamid ) )
                StoreHandler.SendMessage( target, string.format( 'Item %s (ID %i) has been added to your Inventory by %s.', item.name, id, self:Nick() or 'Unknown' ) )
            else
                print( 'Error, this user has no save.' )
            end
        else
            print( 'Error, player is not online.' )
        end
    end )

    util.AddNetworkString( 'StoreHandler.Process.FeatureUpdate' )
    function StoreHandler.HandleGenerationList( id, page, send_client_data )
        -- If an ID is passed with no page, we'll regenerate all pages.
        for k, v in pairs( StoreHandler.FeatureManager ) do
            if id and id ~= k then continue end
            for x, o in pairs( v ) do
                if not o.page_has_features then continue end 
                if page and page ~= x then continue end
                local forced, manual = {}, 0
                for key, item in pairs( StoreHandler.NPCs[ k ].store_items ) do
                    -- This handles items that are forced to be featured.
                    if not item.properties.force_set_feature then continue end
                    if item.page ~= x then continue end
                    if #forced > 2 then continue end
                    table.insert( forced, item )
                end
                if #forced < 2 then
                    local free, stripped = {}, false
                    if #forced == 1 then table.insert( free, forced[ 1 ] ) stripped = true  end -- Take force_set_feature item, they fucked up config.
                    local t = StoreHandler.GrabPossibleItems( k, x )
                    for i = 1, stripped and 1 or 2 do
                        local pick = t[ math.random( 1, #t ) ]
                        if table.HasValue( free, pick ) then
                            for z = 1, 8 do -- Not sure if there's a better way to do this, but cycle through for up to 8 times until we find a free item.
                                if #free == 2 then break end
                                pick = t[ math.random( 1, #t ) ]
                                if not table.HasValue( free, pick ) then
                                    table.insert( free, pick )
                                    break
                                end
                            end
                        else
                            table.insert( free, pick )
                        end
                    end
                    o.featured_items = free
                else
                    o.featured_items = forced
                end
            end
        end
        if send_client_data and id then
            net.Start( 'StoreHandler.Process.FeatureUpdate' )
                net.WriteString( id )
                net.WriteTable( StoreHandler.FeatureManager[ id ] )
                net.WriteString( page )
                net.WriteTable( StoreHandler.Saves )
            net.Broadcast()
        end
    end

    util.AddNetworkString( 'StoreHandler.Manage.Action' )
    function StoreHandler.HandlePurchase( size, self )
        local id, withdrawl = net.ReadInt( 8 ), net.ReadBool()
        local store_id = self.tstore_last_id 
        if not store_id then print( self:Nick() .. ' did not open the store properly. They may be trying to exploit.' ) return end
        local tbl = StoreHandler.NPCs[ store_id ]
        if not tbl then return end

        if tbl.restricted_to and not tbl.restricted_to[ self:GetUserGroup() ] then
            StoreHandler.SendMessage( self, lang.string_no_permission )
            return
        end

        if tbl.job_restrictions and not tbl.job_restrictions[ team.GetName( self:Team() ) ] then
            StoreHandler.SendMessage( self, 'Your job can not purchase this item.' )
            return
        end

        local validItem, item = StoreHandler.FindStoreItem( id )
        if not validItem then print( 'That item doesn\'t exist.' ) return end

        local type = string.lower( item.properties.type )

        if not type then print( item.name .. ' has no type set to it. Set one, or this item will not function.' ) return end    

        if item.restricted_to then 
            if not item.restricted_to[ self:GetUserGroup() ] then StoreHandler.SendMessage( self, lang.string_no_permission ) return end
        end

        if not StoreHandler.OwnsItem( self, item.id ) then
            if withdrawl then print( self:Nick() .. ' is trying to withdraw an item they do not own. They may be trying to exploit.' ) return end
            if not StoreHandler.CanAfford( self, item.price ) then StoreHandler.SendMessage( self, string.format( lang.string_cant_afford_item, item.name, '(' .. item.properties.type .. ')', StoreHandler.Price( item.price ) ) ) return end
            if type == 'weapon' then 
                if self:HasWeapon( item.ent ) then StoreHandler.SendMessage( self, lang.string_item_in_inventory ) return end
            elseif type == 'model' then
                if self:GetModel() == item.model then StoreHandler.SendMessage( self, lang.string_skin_equipped ) return end
            end
            local isPerm = item.properties.permanent_item or type == 'rank' -- Force set this shit.
            if item.properties.permanent_item then 
                if type == 'model' or type == 'weapon' then 
                    StoreHandler.WriteStoreData( self, item.id ) 
                else
                    StoreHandler.SendMessage( self, 'Opps, this item can not go inside of your Locker. Configuration mistake, contact an admin. You have not been charged.' )
                    return
                end
            end
            StoreHandler.SendMessage( self, string.format( lang.string_item_bought, item.name .. ' (' .. item.properties.type .. ')', StoreHandler.Price( item.price ), isPerm and 'permanent' or 'temporary' ) ) 
            StoreHandler.TakeCurrency( self, item.price )  
        else
            if type == 'weapon' then 
                if self:HasWeapon( item.ent ) then StoreHandler.SendMessage( self, lang.string_item_in_inventory ) return end
                StoreHandler.SendMessage( self, string.format( lang.string_item_withdrawn, item.name ) ) 
            elseif type == 'model' then
                if self:GetModel() == item.model then StoreHandler.SendMessage( self, lang.string_skin_equipped ) return end
                StoreHandler.SendMessage( self, string.format( lang.string_item_withdrawn, item.name ) ) 
            end
        end

        if type == 'weapon' then
            self:Give( item.ent )
            self:SelectWeapon( item.ent )
        elseif type == 'entity' or type == 'prop' then -- Same shit, don't want to confuse people.
            StoreHandler.CreateEntity( self, item )
        elseif type == 'shipment' then
            StoreHandler.CreateShipment( self, item )
        elseif type == 'rank' then
            StoreHandler.HandleRank( self, item )
        elseif type == 'model' then
            self:SetModel( item.model )
        end
    end
    net.Receive( 'StoreHandler.Manage.Action', StoreHandler.HandlePurchase )

    function StoreHandler.HandleTime()
        StoreHandler.FeatureManager = {}
        for x, o in pairs( StoreHandler.NPCs ) do
            if not StoreHandler.FeatureManager[ o.id ] then StoreHandler.FeatureManager[ o.id ] = {} end
            for k, v in pairs( o.store_categories ) do 
                local tbl = StoreHandler.FeatureManager[ o.id ]
                local size = StoreHandler.GetFeatureSize( o.id, v.tab )
                if not tbl[ v.tab ] then tbl[ v.tab ] = { page_has_features = size > 0 } end
                if size < 1 then continue end
                tbl[ v.tab ] = {
                    start_time = CurTime(), 
                    feature_length =  v.feature_time, 
                    featured_items = {},
                    is_switching_state = false,
                    page_has_features = true
                }
                timer.Create( string.format( 'FeatureTime%s%s', o.id, v.tab ), v.feature_time, 0, function()
                    tbl[ v.tab ] = {
                        start_time = CurTime(), 
                        feature_length =  v.feature_time, 
                        featured_items = {},
                        is_switching_state = false,
                        page_has_features = true
                    }
                    StoreHandler.HandleGenerationList( o.id, v.tab, true )
                end )
            end
        end
        StoreHandler.HandleGenerationList()
    end
    hook.Add( 'Initialize', 'StoreHandler.Handle.Initialize', StoreHandler.HandleTime )

    function StoreHandler.CreateNPC( pos, angle, store_name, overhead, store_id, model )
        local shop = ents.Create( 'store_base' )
        shop:SetPos( pos )
        shop:SetAngles( angle )
        shop:SetModel( model )
        shop:SetStoreName( store_name )
        shop:Spawn()
        shop:DropToFloor()
        StoreHandler.RegisterOverhead( shop, store_id, overhead )
        shop.store_id = store_id
    end

    function StoreHandler.HandleNPCSpawns()
        for k, v in pairs( StoreHandler.NPCs ) do
            local choice = math.random( 1, #v.position )
            local pos, angle = v.position[ choice ].pos, v.position[ choice ].angle
            if not v.spawn_chance or v.spawn_chance == 100 then
                StoreHandler.CreateNPC( pos, angle, v.store_name, v.overhead, v.id, v.model )
            else
                local chance, main_roll = v.spawn_chance, math.random( 1, 100 )
                if main_roll <= chance then StoreHandler.CreateNPC( pos, angle, v.store_name, v.overhead, v.id, v.model ) end
            end
        end
    end
    hook.Add( 'InitPostEntity', 'StoreHandler.Spawn.NPCs', StoreHandler.HandleNPCSpawns )

    util.AddNetworkString( 'StoreHandler.Send.EntStore' )
    function StoreHandler.GetEntityData( size, self )
        local ent = net.ReadEntity()
        if not IsValid( ent ) then return end
        net.Start( 'StoreHandler.Send.EntStore' )
            net.WriteString( StoreHandler.Overheads[ ent:GetStoreID() ] )
            net.WriteEntity( ent )
        net.Send( self )
    end
    net.Receive( 'StoreHandler.Send.EntStore', StoreHandler.GetEntityData )

    function StoreHandler.SendUserWeapons( self )
        if not StoreHandler.GiveWeaponsOnSpawn then hook.Remove( 'PlayerSpawn', 'StoreHandler.Handle.Weapons' ) return end
        for k, v in pairs( StoreHandler.NPCs ) do
            for x, o in pairs( v.store_items ) do
                if StoreHandler.OwnsItem( self, o.id ) then
                    if string.lower( o.properties.type ) == 'weapon' then self:Give( o.ent ) end
                end
            end
        end
        StoreHandler.SendMessage( self, 'Your permanent items have been given to you.' )
    end
    hook.Add( 'PlayerSpawn', 'StoreHandler.Handle.Weapons', StoreHandler.SendUserWeapons )

-- vk.com/urbanichka
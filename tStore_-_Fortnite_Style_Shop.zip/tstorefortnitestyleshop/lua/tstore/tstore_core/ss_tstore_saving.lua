

    if not SERVER then return end

    function StoreHandler.CreateSaveDirectories()
            if not file.IsDir( 'tstore', 'DATA' ) then file.CreateDir( 'tstore' ) end
            if not file.Exists( 'tstore/saves.txt', 'DATA' ) then 
                file.Write( 'tstore/saves.txt', '[]' ) 
            else
                local data = util.JSONToTable( file.Read( 'tstore/saves.txt', 'DATA' ) )
                if not data then return end
                StoreHandler.Saves = data
            end 
        end 
    hook.Add( 'Initialize', 'StoreHandler.Create.StoreDirectories', StoreHandler.CreateSaveDirectories )

    function StoreHandler.WriteStoreData( self, entry )
        if not StoreHandler.Saves[ self:SteamID() ] then StoreHandler.Saves[ self:SteamID() ] = {} end
        if entry then table.insert( StoreHandler.Saves[ self:SteamID() ], entry ) end
        file.Write( 'tstore/saves.txt', util.TableToJSON( StoreHandler.Saves ) )
    end

-- vk.com/urbanichka
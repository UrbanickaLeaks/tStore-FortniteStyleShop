

    StoreHandler = StoreHandler or {}
    StoreHandler.NPCs = StoreHandler.NPCs or {}
    StoreHandler.Saves = StoreHandler.Saves or {}
    StoreHandler.Themes = StoreHandler.Themes or {}
    StoreHandler.Languages = StoreHandler.Languages or {}
    StoreHandler.Overheads = StoreHandler.Overheads or {}

    local fuck_up_table = { 
        { f = 'darkrp', h = '$' }, { f = 'pointshop1', h = ' Points' }, { f = 'pointshop2',  h = ' Points' },
        { f = 'basewars', h = '$' }
    }

    function StoreHandler.Price( price )
        local curr = string.lower( StoreHandler.Currency )
        local has, format = false, ''
        for k, v in pairs( fuck_up_table ) do if curr == v.f then has, format = true, v.h end end
        if not has then return 'Price Error' end
        local str = ''
        if format == '$' then str = format .. string.Comma( price ) else str = string.Comma( price ) .. format end
        return str
    end

    function StoreHandler.UsingClassic() return string.lower( StoreHandler.Themes.Choice ) == 'classic' end

    function StoreHandler.CreateStore( data )
        local id = data.id
        StoreHandler.NPCs[ id ] = {
            id = id,
            overhead = data.overhead or 'Store',
            model = data.model or 'models/Humans/Group03/male_09.mdl',
            description = data.description or 'No description set :(',
            position = data.position or Vector( 0, 0, 0 ),
            angle = data.angle or Angle( 0, 90, 0 ),
            store_name = data.store_name or 'Store',
            store_categories = data.store_categories or { 'General' },
            spawn_chance = data.spawn_chance or 100,
            store_items = data.store_items or {},
            restricted_to = data.restricted_to,
            job_restrictions = data.job_restrictions
        }
    end
    
    function StoreHandler.AddItem( npc_id, tbl )
        if not StoreHandler.NPCs[ npc_id ] then print( 'Error, this NPC does not exist. Can not add item to it.' ) return end
        if not StoreHandler.NPCs[ npc_id ].store_items then StoreHandler.NPCs[ npc_id ].store_items = {} end
        for k, v in pairs( StoreHandler.NPCs[ npc_id ].store_items ) do if v.id == tbl.id then table.RemoveByValue( StoreHandler.NPCs[ npc_id ].store_items, v ) end end -- This shit is just annoying.
        table.insert( StoreHandler.NPCs[ npc_id ].store_items, tbl )
    end

    function StoreHandler.RegisterOverhead( shop, store_id, overhead )
        if not IsValid( shop ) then return end
        shop:SetStoreID( store_id )
        if not StoreHandler.Overheads[ store_id ] then 
            StoreHandler.Overheads[ store_id ] = overhead
        end
    end



-- vk.com/urbanichka
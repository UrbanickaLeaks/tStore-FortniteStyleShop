local root, ss_folder, cs_folder, config_folder = 'tstore/', 'tstore_core', 'tstore_vgui', 'tstore_config_manager'

local ss_files = {
    string.format( root .. '%s/%s', ss_folder, 'sh_tstore_construct.lua' ),
    string.format( root .. '%s/%s', config_folder, 'tstore_npc_config.lua' ),
    string.format( root .. '%s/%s', config_folder, 'tstore_item_config.lua' ),
    string.format( root .. 'sh_tstore_config.lua' ),
    string.format( root .. 'sh_tstore_language.lua' ),
    string.format( root .. '%s/%s', ss_folder, 'ss_tstore_saving.lua' ),
    string.format( root .. '%s/%s', ss_folder, 'ss_tstore_core.lua' )
}

local cs_files = {
    string.format( root .. '%s/%s', ss_folder, 'sh_tstore_construct.lua' ),
    string.format( root .. '%s/%s', config_folder, 'tstore_npc_config.lua' ),
    string.format( root .. '%s/%s', config_folder, 'tstore_item_config.lua' ),
    string.format( root .. 'sh_tstore_config.lua' ),
    string.format( root .. 'sh_tstore_language.lua' ),
    string.format( root .. '%s/%s', cs_folder, 'cs_tstore_functions.lua' ),
    string.format( root .. '%s/%s', cs_folder, 'cs_tstore_themes.lua' ),
    string.format( root .. '%s/%s', cs_folder, 'cs_tstore_template.lua' ),
    string.format( root .. '%s/%s', cs_folder, 'cs_tstore_store.lua' ),
    string.format( root .. '%s/%s', cs_folder, 'cs_tstore_other.lua' )
}

if SERVER then
    resource.AddFile( 'resource/fonts/bfhud.ttf' )
    resource.AddFile( 'resource/fonts/luckiestguy.ttf' )
--   resource.AddWorkshop( '1443126934' )
    for k, v in pairs( cs_files ) do AddCSLuaFile( v ) end
    for k, v in pairs( ss_files ) do include( v ) end
else
    for k, v in pairs( cs_files ) do include( v ) end
end

-- vk.com/urbanichka